package br.edu.icomp.tp2_implementacao;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class Database extends SQLiteOpenHelper {
    public static final int DATABASE_VERSION = 4;
    public static final String DATABASE_NAME = "LocadoraRelampago.db";

    private static final String SQL_CREATE_PASS = "CREATE TABLE clientes (" + "id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT, senha TEXT," + "idade TEXT)";

    private static final String SQL_CREATE_PASS2 = "CREATE TABLE veiculos (" + "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
            "placa TEXT,categoria TEXT, numero_maximo_de_passageiros TEXT, tamanho_do_bagageiro TEXT, tipo_de_cambio TEXT," +
            " possui_ar_condicionado TEXT, media_de_consumo TEXT, acessorios TEXT, custo_por_dia TEXT)";

    private static final String SQL_CREATE_PASS3 = "CREATE TABLE alugados (" + "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
            "Placa_Carro_Alugado TEXT,Nome_completo TEXT, Local_de_retirada TEXT, Data_de_retirada TEXT, Local_de_devolucao TEXT," +
            " Data_de_devolucao TEXT, Opcionais TEXT, valorTotal TEXT)";



    private static final String SQL_POPULATE_PASS1 = "INSERT INTO clientes VALUES " + "(NULL, 'Alberto Nascimento', '12345', '56')";
    private static final String SQL_POPULATE_PASS2 = "INSERT INTO clientes VALUES " + "(NULL, 'Marcos', '40028922', '20')";
    private static final String SQL_POPULATE_PASS3= "INSERT INTO clientes VALUES " + "(NULL, 'Maria das dores', '54321', '60')";


    private static final String SQL_POPULATE_PASS4 = "INSERT INTO veiculos VALUES " + "(NULL, 'NOJ-0481', 'Grande', '7','Grande'," +
            "'Manual','Sim','10','AirBag,FreioABS','150')";

    private static final String SQL_POPULATE_PASS5 = "INSERT INTO veiculos VALUES " + "(NULL, 'DAC-5892', 'Premium', '1','Pequeno'," +
            "'Automático','Sim','15','AirBag,FreioABS,DVD','200')";

    private static final String SQL_POPULATE_PASS6 = "INSERT INTO veiculos VALUES " + "(NULL, 'ECO-4589', 'Econômico', '4','Médio'," +
            "'Manual','Não','5','AirBag','100')";


    private static final String SQL_POPULATE_PASS7 = "INSERT INTO alugados VALUES " + "(NULL, 'DAC-5892', 'Marcos', 'Agencia Cidade Nova','25/05/2022'," +
            "'Agencia UFAM','30/05/2022','GPS,Assento para crianças,Seguro completo','1500')";


    private static final String SQL_DELETE_PASS = "DROP TABLE IF EXISTS clientes";
    private static final String SQL_DELETE_PASS2 = "DROP TABLE IF EXISTS veiculos";
    private static final String SQL_DELETE_PASS3 = "DROP TABLE IF EXISTS alugados";


    public Database(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_PASS);
        db.execSQL(SQL_CREATE_PASS2);
        db.execSQL(SQL_CREATE_PASS3);
        db.execSQL(SQL_POPULATE_PASS1);
        db.execSQL(SQL_POPULATE_PASS2);
        db.execSQL(SQL_POPULATE_PASS3);
        db.execSQL(SQL_POPULATE_PASS4);
        db.execSQL(SQL_POPULATE_PASS5);
        db.execSQL(SQL_POPULATE_PASS6);
        db.execSQL(SQL_POPULATE_PASS7);

    }

    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(SQL_DELETE_PASS);
        db.execSQL(SQL_DELETE_PASS2);
        db.execSQL(SQL_DELETE_PASS3);
        onCreate(db);
    }
}
