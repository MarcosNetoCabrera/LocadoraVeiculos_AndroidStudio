package br.edu.icomp.tp2_implementacao;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class telaEdicaoAluguel extends AppCompatActivity {
    VeiculoDAO veiculoDAO;
    ClienteDAO clienteDAO;
    private int clienteID;
    private int veiculoID;
    private TextView editPlaca, editCategoria, editNumero_maximo_de_passageiros,editTamanho_do_bagageiro,editTipo_de_cambio,editPossui_ar_condicionado;
    private TextView editMedia_de_consumo,editCusto_por_dia,editAcessorios;
    private Button bt_alugar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_edicao_aluguel);

        getSupportActionBar().hide();

        editPlaca = findViewById(R.id.textPlaca);
        editCategoria = findViewById(R.id.textCategoria);
        editNumero_maximo_de_passageiros = findViewById(R.id.textNumero_passageiros);
        editTamanho_do_bagageiro = findViewById(R.id.textTamanho_do_bagageiro);
        editTipo_de_cambio = findViewById(R.id.textTipo_de_cambio);
        editPossui_ar_condicionado = findViewById(R.id.textPossui_ar_condicionado);
        editMedia_de_consumo = findViewById(R.id.textMedia_de_consumo);
        editAcessorios = findViewById(R.id.textAcessorios);
        editCusto_por_dia = findViewById(R.id.textCusto_por_dia);

        veiculoDAO = new VeiculoDAO(this);
        Intent intent = getIntent();
        veiculoID = intent.getIntExtra("veiculoID", -1);

        clienteDAO = new ClienteDAO(this);
        intent = getIntent();
        clienteID = intent.getIntExtra("clienteID", -1);

        if (veiculoID != -1) {
            Veiculo veiculo = veiculoDAO.get(veiculoID);
            editPlaca.setText(veiculo.getPlaca());
            editCategoria.setText(veiculo.getCategoria());
            editNumero_maximo_de_passageiros.setText(veiculo.getNumero_maximo_de_passageiros() + " Passageiros");
            editTamanho_do_bagageiro.setText(veiculo.getTamanho_do_bagageiro());
            editTipo_de_cambio.setText(veiculo.getTipo_de_cambio());
            editPossui_ar_condicionado.setText(veiculo.getPossui_ar_condicionado());
            editMedia_de_consumo.setText(veiculo.getMedia_de_consumo() + " (km/l)");
            editAcessorios.setText(veiculo.getAcessorios());
            editCusto_por_dia.setText(veiculo.getCusto_por_dia() + " Reais por dia");
        }

        bt_alugar = findViewById(R.id.buttonAlugar);
        bt_alugar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(telaEdicaoAluguel.this, telaAluguel.class);
                intent.putExtra("veiculoID",veiculoID);
                intent.putExtra("clienteID",clienteID);
                startActivity(intent);
            }
        });
    }
}