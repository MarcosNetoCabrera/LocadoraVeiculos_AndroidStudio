package br.edu.icomp.tp2_implementacao;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class telaCadastro extends AppCompatActivity {

    private Button bt_confirma;
    private TextView editName,editSenha,editIdade;
    ClienteDAO clienteDAO;
    public void inicializa(){
        bt_confirma = findViewById(R.id.buttonConfirmar);
        editName = findViewById(R.id.edit_nome);
        editSenha = findViewById(R.id.edit_senha_cadastro);
        editIdade = findViewById(R.id.edit_idade);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_cadastro);

        inicializa();

        getSupportActionBar().hide();
        clienteDAO = new ClienteDAO(this);

        bt_confirma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nome = editName.getText().toString();
                String senha = editSenha.getText().toString();
                String idade = editIdade.getText().toString();

                if(nome.isEmpty() || senha.isEmpty() || idade.isEmpty()){
                    Toast.makeText(telaCadastro.this, "Preencha todos os campos", Toast.LENGTH_SHORT).show();
                }else{
                    if(Integer.parseInt(idade)<18){
                        Toast.makeText(telaCadastro.this, "Você deve ter mais de 18 anos para se cadastrar", Toast.LENGTH_SHORT).show();
                    }else{
                        Cliente cliente = new Cliente(-1, editName.getText().toString(),
                                editSenha.getText().toString(),editIdade.getText().toString());

                        boolean result;

                        result = clienteDAO.add(cliente);
                        if(result==true){

                            Cliente cliente2 = clienteDAO.BuscarSenha(cliente.getSenha());
                            Intent intent = new Intent(telaCadastro.this,telaControle.class);
                            intent.putExtra("clienteID",cliente2.getId());
                            startActivity(intent);
                        }else{
                            Toast.makeText(telaCadastro.this, "Tente novamente", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            }
        });
    }
}