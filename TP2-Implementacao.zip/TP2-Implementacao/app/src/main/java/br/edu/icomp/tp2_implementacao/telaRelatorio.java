package br.edu.icomp.tp2_implementacao;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

public class telaRelatorio extends AppCompatActivity {
    private RecyclerView recyclerView;
    private telaRelatorio.AluguelAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_relatorio);

        getSupportActionBar().hide();

        recyclerView = findViewById(R.id.list_recycle4);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapter = new telaRelatorio.AluguelAdapter(this);
        recyclerView.setAdapter(adapter);

    }

    protected void onRestart() {
        super.onRestart();
        adapter.update();
        adapter.notifyDataSetChanged();
    }

    class AluguelAdapter extends RecyclerView.Adapter<AluguelViewHolder> {
        private Context context;
        private ArrayList<Aluguel> alugados;
        AluguelDAO aluguelDAO;

        public AluguelAdapter(Context context) {
            this.context = context;
            aluguelDAO = new AluguelDAO(context);
            update();
        }

        public void update() { alugados = aluguelDAO.getList(); }

        public AluguelViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            ConstraintLayout v = (ConstraintLayout) LayoutInflater
                    .from(parent.getContext())
                    .inflate(R.layout.list_item3, parent, false);
            AluguelViewHolder vh = new AluguelViewHolder(v, context);
            return vh;
        }

        public void onBindViewHolder(AluguelViewHolder holder, int position) {
            holder.id = alugados.get(position).getID();
            holder.nome.setText(alugados.get(position).getNome_completo());
            holder.placa.setText(alugados.get(position).getPlaca_Carro_Alugado());
        }
        public int getItemCount() { return alugados.size(); }
    }


    class AluguelViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public Context context;
        public TextView nome,placa;
        public int id;

        public AluguelViewHolder(ConstraintLayout v, Context context) {
            super(v);
            this.context = context;
            nome = v.findViewById(R.id.itemName3);
            placa = v.findViewById(R.id.itemSenha3);
            v.setOnClickListener(this);
        }

        public void onClick(View v) {

            Intent intent = new Intent(context, telaExibirRelatorio.class);
            intent.putExtra("aluguelID", this.id);
            context.startActivity(intent);

        }

    }
}