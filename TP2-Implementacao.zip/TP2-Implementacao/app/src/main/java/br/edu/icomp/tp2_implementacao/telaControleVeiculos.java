package br.edu.icomp.tp2_implementacao;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class telaControleVeiculos extends AppCompatActivity {
    private RecyclerView recyclerView;
    private telaControleVeiculos.VeiculosAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_controle_veiculos);
        getSupportActionBar().hide();

        recyclerView = findViewById(R.id.list_recycle2);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapter = new telaControleVeiculos.VeiculosAdapter(this);
        recyclerView.setAdapter(adapter);
    }
    public void buttonAddClick2(View view) {
        Intent intent = new Intent(this, telaEdicaoVeiculo.class);
        startActivity(intent);
    }
    public void buttonRelatori2(View view) {
        Intent intent = new Intent(this, telaRelatorio.class);
        startActivity(intent);
    }

    protected void onRestart() {
        super.onRestart();
        adapter.update();
        adapter.notifyDataSetChanged();
    }

    class VeiculosAdapter extends RecyclerView.Adapter<telaControleVeiculos.VeiculosViewHolder> {
        private Context context;
        private ArrayList<Veiculo> veiculos;
        VeiculoDAO veiculoDAO;

        public VeiculosAdapter(Context context) {
            this.context = context;
            veiculoDAO = new VeiculoDAO(context);
            update();
        }

        public void update() { veiculos = veiculoDAO.getList(); }

        public telaControleVeiculos.VeiculosViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            ConstraintLayout v = (ConstraintLayout) LayoutInflater
                    .from(parent.getContext())
                    .inflate(R.layout.list_item2, parent, false);
            telaControleVeiculos.VeiculosViewHolder vh = new telaControleVeiculos.VeiculosViewHolder(v, context);
            return vh;
        }

        public void onBindViewHolder(telaControleVeiculos.VeiculosViewHolder holder, int position) {
            holder.id = veiculos.get(position).getId();
            holder.Placa.setText(veiculos.get(position).getPlaca());
            holder.Categoria.setText(veiculos.get(position).getCategoria());
        }
        public int getItemCount() { return veiculos.size(); }
    }


    class VeiculosViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public Context context;
        public TextView Placa,Categoria;
        public int id;

        public VeiculosViewHolder(ConstraintLayout v, Context context) {
            super(v);
            this.context = context;
            Placa = v.findViewById(R.id.itemName2);
            Categoria = v.findViewById(R.id.itemSenha2);
            v.setOnClickListener(this);
        }

        public void onClick(View v) {

            //Toast.makeText(context, "Olá " + this.Placa.getText().toString(), Toast.LENGTH_LONG).show();

            Intent intent = new Intent(context, telaEdicaoVeiculo.class);
            intent.putExtra("veiculoID", this.id);
            context.startActivity(intent);


        }

    }
}