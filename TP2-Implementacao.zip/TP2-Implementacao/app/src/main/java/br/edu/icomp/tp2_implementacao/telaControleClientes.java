package br.edu.icomp.tp2_implementacao;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class telaControleClientes extends AppCompatActivity {
    private RecyclerView recyclerView;
    private ClienteAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_controle_clientes);
        getSupportActionBar().hide();

        recyclerView = findViewById(R.id.list_recycle);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapter = new ClienteAdapter(this);
        recyclerView.setAdapter(adapter);

    }
    public void buttonAddClick(View view) {
        Intent intent = new Intent(this, telaEdicaoCliente.class);
        startActivity(intent);
    }

    public void buttonRelatorio1(View view) {
        Intent intent = new Intent(this, telaRelatorio.class);
        startActivity(intent);
    }



    protected void onRestart() {
        super.onRestart();
        adapter.update();
        adapter.notifyDataSetChanged();
    }

    class ClienteAdapter extends RecyclerView.Adapter<ClientesViewHolder> {
        private Context context;
        private ArrayList<Cliente> clientes;
        ClienteDAO clienteDAO;

        public ClienteAdapter(Context context) {
            this.context = context;
            clienteDAO = new ClienteDAO(context);
            update();
        }

        public void update() { clientes = clienteDAO.getList(); }

        public ClientesViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            ConstraintLayout v = (ConstraintLayout) LayoutInflater
                    .from(parent.getContext())
                    .inflate(R.layout.list_item, parent, false);
            ClientesViewHolder vh = new ClientesViewHolder(v, context);
            return vh;
        }

        public void onBindViewHolder(ClientesViewHolder holder, int position) {
            holder.id = clientes.get(position).getId();
            holder.nome.setText(clientes.get(position).getNome());
            holder.senha.setText(clientes.get(position).getSenha());
        }
        public int getItemCount() { return clientes.size(); }
    }


    class ClientesViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public Context context;
        public TextView senha,nome;
        public int id;

        public ClientesViewHolder(ConstraintLayout v, Context context) {
            super(v);
            this.context = context;
            nome = v.findViewById(R.id.itemName);
            senha = v.findViewById(R.id.itemSenha);
            v.setOnClickListener(this);
        }

        public void onClick(View v) {

            //Toast.makeText(context, "Olá " + this.nome.getText().toString(), Toast.LENGTH_LONG).show();

            Intent intent = new Intent(context, telaEdicaoCliente.class);
            intent.putExtra("clienteID", this.id);
            context.startActivity(intent);


        }

    }

}