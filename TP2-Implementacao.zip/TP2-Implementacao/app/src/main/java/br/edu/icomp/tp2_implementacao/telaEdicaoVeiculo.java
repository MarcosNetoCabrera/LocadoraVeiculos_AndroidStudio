package br.edu.icomp.tp2_implementacao;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class telaEdicaoVeiculo extends AppCompatActivity {
    private VeiculoDAO veiculoDAO;
    private int veiculoID;
    private TextView editPlaca, editCategoria, editNumero_maximo_de_passageiros,editTamanho_do_bagageiro,editTipo_de_cambio,editPossui_ar_condicionado;
    private TextView editMedia_de_consumo,editCusto_por_dia,editAcessorios;
    private Button bt_salvar2, bt_remove2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_edicao_veiculo);

        getSupportActionBar().hide();

        editPlaca = findViewById(R.id.edit_placa);
        editCategoria = findViewById(R.id.edit_categoria);
        editNumero_maximo_de_passageiros = findViewById(R.id.edit_numero_passageiros);
        editTamanho_do_bagageiro = findViewById(R.id.edit_Tamanho_do_bagageiro);
        editTipo_de_cambio = findViewById(R.id.edit_Tipo_de_cambio);
        editPossui_ar_condicionado = findViewById(R.id.edit_Possui_ar_condicionado);
        editMedia_de_consumo = findViewById(R.id.edit_Media_de_consumo);
        editAcessorios = findViewById(R.id.edit_Acessorios);
        editCusto_por_dia = findViewById(R.id.edit_Custo_por_dia);

        veiculoDAO = new VeiculoDAO(this);
        Intent intent = getIntent();
        veiculoID = intent.getIntExtra("veiculoID", -1);

        if (veiculoID != -1) {
            Veiculo veiculo = veiculoDAO.get(veiculoID);
            editPlaca.setText(veiculo.getPlaca());
            editCategoria.setText(veiculo.getCategoria());
            editNumero_maximo_de_passageiros.setText(veiculo.getNumero_maximo_de_passageiros());
            editTamanho_do_bagageiro.setText(veiculo.getTamanho_do_bagageiro());
            editTipo_de_cambio.setText(veiculo.getTipo_de_cambio());
            editPossui_ar_condicionado.setText(veiculo.getPossui_ar_condicionado());
            editMedia_de_consumo.setText(veiculo.getMedia_de_consumo());
            editAcessorios.setText(veiculo.getAcessorios());
            editCusto_por_dia.setText(veiculo.getCusto_por_dia());

        }
        bt_salvar2 = findViewById(R.id.buttonSalvar2);
        bt_salvar2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String placa = editPlaca.getText().toString();
                String categoria = editCategoria.getText().toString();
                String passageiros = editNumero_maximo_de_passageiros.getText().toString();
                String bagageiro = editTamanho_do_bagageiro.getText().toString();
                String cambio = editTipo_de_cambio.getText().toString();
                String ar = editPossui_ar_condicionado.getText().toString();
                String consumo = editMedia_de_consumo.getText().toString();
                String acessorios = editAcessorios.getText().toString();
                String custo = editCusto_por_dia.getText().toString();
                if(placa.isEmpty() || categoria.isEmpty() || passageiros.isEmpty() || bagageiro.isEmpty() || cambio.isEmpty() || ar.isEmpty() || consumo.isEmpty() || acessorios.isEmpty() || custo.isEmpty()){
                    Toast.makeText(telaEdicaoVeiculo.this,"Preencha todos os campos", Toast.LENGTH_SHORT).show();
                }else{
                    Veiculo veiculo = new Veiculo(veiculoID, editPlaca.getText().toString(), editCategoria.getText().toString(),
                            editNumero_maximo_de_passageiros.getText().toString(),editTamanho_do_bagageiro.getText().toString(),
                            editTipo_de_cambio.getText().toString(),editPossui_ar_condicionado.getText().toString(),
                            editMedia_de_consumo.getText().toString(),editAcessorios.getText().toString(),editCusto_por_dia.getText().toString());

                    boolean result;
                    if (veiculoID == -1) result = veiculoDAO.add(veiculo);
                    else result = veiculoDAO.update(veiculo);

                    if (result) finish();
                }
            }
        });
        bt_remove2 = findViewById(R.id.buttonRemover2);
        bt_remove2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(veiculoID==-1){
                    Toast.makeText(telaEdicaoVeiculo.this,"Não a veículo cadastrado para remover", Toast.LENGTH_SHORT).show();
                }else{
                    Veiculo veiculo = veiculoDAO.get(veiculoID);
                    boolean result;
                    result = veiculoDAO.remover(veiculo);
                    if (result) finish();
                }

            }
        });
    }
}