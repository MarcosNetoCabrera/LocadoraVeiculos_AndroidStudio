package br.edu.icomp.tp2_implementacao;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class telaEdicaoCliente extends AppCompatActivity {
    private ClienteDAO clienteDAO;
    private int clienteID;
    private TextView editName, editSenha, editIdade;
    private Button bt_salvar,bt_remove;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_edicao_cliente);
        getSupportActionBar().hide();

        editName = findViewById(R.id.edit_nomeControle);
        editIdade = findViewById(R.id.edit_idadeControle);
        editSenha = findViewById(R.id.edit_senha_cadastroControle);

        clienteDAO = new ClienteDAO(this);
        Intent intent = getIntent();
        clienteID = intent.getIntExtra("clienteID", -1);

        if (clienteID != -1) {
            Cliente cliente = clienteDAO.get(clienteID);
            editName.setText(cliente.getNome());
            editSenha.setText(cliente.getSenha());
            editIdade.setText(cliente.getIdade());
        }
        bt_salvar = findViewById(R.id.buttonSalvar);
        bt_salvar.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View view) {
                String nome = editName.getText().toString();
                String senha = editSenha.getText().toString();
                String idade = editIdade.getText().toString();

                if(nome.isEmpty() || senha.isEmpty() || idade.isEmpty()) {
                    Toast.makeText(telaEdicaoCliente.this, "Preencha todos os campos", Toast.LENGTH_SHORT).show();
                }else{
                    Cliente cliente = new Cliente(clienteID, editName.getText().toString(),
                            editSenha.getText().toString(),editIdade.getText().toString());

                    boolean result;
                    if (clienteID == -1) result = clienteDAO.add(cliente);
                    else                  result = clienteDAO.update(cliente);

                    if (result) finish();
                }
            }
        });
        bt_remove = findViewById(R.id.buttonRemover);
        bt_remove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(clienteID != -1){
                    Cliente cliente = clienteDAO.get(clienteID);
                    boolean result;
                    result = clienteDAO.remover(cliente);
                    if (result) finish();
                }else{
                    Toast.makeText(telaEdicaoCliente.this,"Não a cliente cadastrado para remover", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }

}