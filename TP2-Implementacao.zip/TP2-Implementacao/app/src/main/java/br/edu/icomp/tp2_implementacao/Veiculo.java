package br.edu.icomp.tp2_implementacao;

public class Veiculo {
    private int id;
    private String Placa;
    private String Categoria;
    private String Numero_maximo_de_passageiros;
    private String Tamanho_do_bagageiro;
    private String Tipo_de_cambio;
    private String Possui_ar_condicionado;
    private String Media_de_consumo;
    private String Acessorios;
    private String Custo_por_dia;

    public Veiculo(int id, String placa, String categoria, String numero_maximo_de_passageiros, String tamanho_do_bagageiro, String tipo_de_cambio, String possui_ar_condicionado, String media_de_consumo, String acessorios, String custo_por_dia) {
        this.id = id;
        this.Placa = placa;
        this.Categoria = categoria;
        this.Numero_maximo_de_passageiros = numero_maximo_de_passageiros;
        this.Tamanho_do_bagageiro = tamanho_do_bagageiro;
        this.Tipo_de_cambio = tipo_de_cambio;
        this.Possui_ar_condicionado = possui_ar_condicionado;
        this.Media_de_consumo = media_de_consumo;
        this.Acessorios = acessorios;
        this.Custo_por_dia = custo_por_dia;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPlaca() {
        return Placa;
    }

    public void setPlaca(String placa) {
        Placa = placa;
    }

    public String getCategoria() {
        return Categoria;
    }

    public void setCategoria(String categoria) {
        Categoria = categoria;
    }

    public String getNumero_maximo_de_passageiros() {
        return Numero_maximo_de_passageiros;
    }

    public void setNumero_maximo_de_passageiros(String numero_maximo_de_passageiros) {
        Numero_maximo_de_passageiros = numero_maximo_de_passageiros;
    }

    public String getTamanho_do_bagageiro() {
        return Tamanho_do_bagageiro;
    }

    public void setTamanho_do_bagageiro(String tamanho_do_bagageiro) {
        Tamanho_do_bagageiro = tamanho_do_bagageiro;
    }

    public String getTipo_de_cambio() {
        return Tipo_de_cambio;
    }

    public void setTipo_de_cambio(String tipo_de_cambio) {
        Tipo_de_cambio = tipo_de_cambio;
    }

    public String getPossui_ar_condicionado() {
        return Possui_ar_condicionado;
    }

    public void setPossui_ar_condicionado(String possui_ar_condicionado) {
        Possui_ar_condicionado = possui_ar_condicionado;
    }

    public String getMedia_de_consumo() {
        return Media_de_consumo;
    }

    public void setMedia_de_consumo(String media_de_consumo) {
        Media_de_consumo = media_de_consumo;
    }

    public String getAcessorios() {
        return Acessorios;
    }

    public void setAcessorios(String acessorios) {
        Acessorios = acessorios;
    }

    public String getCusto_por_dia() {
        return Custo_por_dia;
    }

    public void setCusto_por_dia(String custo_por_dia) {
        Custo_por_dia = custo_por_dia;
    }
}
