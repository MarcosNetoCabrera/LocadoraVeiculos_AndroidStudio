package br.edu.icomp.tp2_implementacao;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentUris;
import android.content.Intent;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private TextView text_tela_cadastro;
    private Button bt_entrar;
    private TextView nome_entrar,senha_entrar;
    private int clienteID;
    ClienteDAO clienteDAO;

    public void IniciarComponentes(){
        text_tela_cadastro = findViewById(R.id.text_cadastrado);
        bt_entrar = findViewById(R.id.buttonEntrar);
        nome_entrar = findViewById(R.id.edit_person);
        senha_entrar = findViewById(R.id.edit_senha);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportActionBar().hide();
        IniciarComponentes();

        clienteDAO = new ClienteDAO(this);

        text_tela_cadastro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,telaCadastro.class);
                startActivity(intent);
            }
        });

        bt_entrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nome = nome_entrar.getText().toString();
                String senha = senha_entrar.getText().toString();
                if(nome.isEmpty() || senha.isEmpty()){
                    Toast.makeText(MainActivity.this, "Preencha todos os campos", Toast.LENGTH_SHORT).show();
                }else{
                    if(clienteDAO.BuscarSenha(senha)==null){
                        Toast.makeText(MainActivity.this, "Senha incorreta", Toast.LENGTH_SHORT).show();
                    }else{
                        Cliente cliente = clienteDAO.BuscarSenha(senha);
                        if(cliente.getSenha().equals(senha) && cliente.getNome().equals(nome)){
                            Intent intent = new Intent(MainActivity.this,telaControle.class);
                            intent.putExtra("clienteID",cliente.getId());
                            startActivity(intent);
                        }else{
                            Toast.makeText(MainActivity.this, "O nome e a senha não coincidem ", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            }
        });
    }
}