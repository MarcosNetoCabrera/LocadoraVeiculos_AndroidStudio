package br.edu.icomp.tp2_implementacao;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class telaExibirRelatorio extends AppCompatActivity {
    private AluguelDAO aluguelDAO;
    private int aluguelID;
    private TextView editPlaca, editNome, editLocal_de_retirada,editData_de_retirada,editLocal_de_devolucao, editData_de_devolucao;
    private TextView editOpcionais,editvalorTotal;
    private Button bt_salvar3, bt_remove3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_exibir_relatorio);

        getSupportActionBar().hide();

        editPlaca = findViewById(R.id.edit_placa_alugado);
        editNome = findViewById(R.id.edit_nomeAlugado);
        editLocal_de_retirada = findViewById(R.id.edit_local_retirada);
        editData_de_retirada = findViewById(R.id.edit_Data_de_retirada);
        editLocal_de_devolucao = findViewById(R.id.edit_local_devolucao);
        editData_de_devolucao = findViewById(R.id.edit_Data_de_devolucao);
        editOpcionais = findViewById(R.id.edit_opcionais);
        editvalorTotal = findViewById(R.id.edit_valorPago);

        aluguelDAO = new AluguelDAO(this);
        Intent intent = getIntent();
        aluguelID = intent.getIntExtra("aluguelID", -1);

        if (aluguelID != -1) {
            Aluguel aluguel = aluguelDAO.get(aluguelID);
            editPlaca.setText(aluguel.getPlaca_Carro_Alugado());
            editNome.setText(aluguel.getNome_completo());
            editLocal_de_retirada.setText(aluguel.getLocal_de_retirada());
            editData_de_retirada.setText(aluguel.getData_de_retirada());
            editLocal_de_devolucao.setText(aluguel.getLocal_de_devolucao());
            editData_de_devolucao.setText(aluguel.getData_de_devolucao());
            editOpcionais.setText(aluguel.getOpcionais());
            editvalorTotal.setText(aluguel.getValorTotal());
        }
        bt_salvar3 = findViewById(R.id.buttonSalvar3);
        bt_salvar3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Aluguel aluguel = new Aluguel(aluguelID, editPlaca.getText().toString(), editNome.getText().toString(),
                        editLocal_de_retirada.getText().toString(),editData_de_retirada.getText().toString(),
                        editLocal_de_devolucao.getText().toString(), editData_de_devolucao.getText().toString(),
                        editOpcionais.getText().toString(),editvalorTotal.getText().toString());

                boolean result;
                if (aluguelID == -1) result = aluguelDAO.add(aluguel);
                else result = aluguelDAO.update(aluguel);

                if (result) finish();
            }
        });
        bt_remove3 = findViewById(R.id.buttonCancelar);
        bt_remove3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Aluguel aluguel = aluguelDAO.get(aluguelID);
                boolean result;
                result = aluguelDAO.remover(aluguel);

                if (result) finish();
            }
        });
    }
}