package br.edu.icomp.tp2_implementacao;

import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Toast;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class VeiculoDAO {
    private Context context;
    private SQLiteDatabase database;

    public VeiculoDAO(Context context) {
        this.context = context;
        this.database = (new Database(context)).getWritableDatabase();
    }

    public ArrayList<Veiculo> getList() {
        ArrayList<Veiculo> result = new ArrayList<Veiculo>();
        String sql = "SELECT * FROM veiculos ORDER BY placa";
        Cursor cursor = database.rawQuery(sql, null);

        while (cursor.moveToNext()) {
            int id = cursor.getInt(0);
            String Placa = cursor.getString(1);
            String Categoria = cursor.getString(2);
            String Numero_maximo_de_passageiros = cursor.getString(3);
            String Tamanho_do_bagageiro = cursor.getString(4);
            String Tipo_de_cambio = cursor.getString(5);
            String Possui_ar_condicionado = cursor.getString(6);
            String Media_de_consumo = cursor.getString(7);
            String Acessorios = cursor.getString(8);
            String Custo_por_dia = cursor.getString(9);
            result.add(new Veiculo(id, Placa, Categoria, Numero_maximo_de_passageiros,Tamanho_do_bagageiro,Tipo_de_cambio,Possui_ar_condicionado,Media_de_consumo,
                    Acessorios,Custo_por_dia));
        }
        return result;
    }
    public ArrayList<Veiculo> getList2() {
        ArrayList<Veiculo> result = new ArrayList<Veiculo>();
        String sql = "SELECT * FROM veiculos ORDER BY placa";
        Cursor cursor = database.rawQuery(sql, null);

        AluguelDAO aluguelDAO = new AluguelDAO(context);

        while (cursor.moveToNext()) {
            int id = cursor.getInt(0);
            String Placa = cursor.getString(1);
            String Categoria = cursor.getString(2);
            String Numero_maximo_de_passageiros = cursor.getString(3);
            String Tamanho_do_bagageiro = cursor.getString(4);
            String Tipo_de_cambio = cursor.getString(5);
            String Possui_ar_condicionado = cursor.getString(6);
            String Media_de_consumo = cursor.getString(7);
            String Acessorios = cursor.getString(8);
            String Custo_por_dia = cursor.getString(9);

            if(!aluguelDAO.buscaPlaca(Placa)){
                result.add(new Veiculo(id, Placa, Categoria,
                        Numero_maximo_de_passageiros,Tamanho_do_bagageiro,Tipo_de_cambio,Possui_ar_condicionado,Media_de_consumo,Acessorios,Custo_por_dia));
            }

        }
        return result;
    }
    public boolean add(Veiculo veiculo) {
        String sql = "INSERT INTO veiculos VALUES (NULL, "
                + "'" + veiculo.getPlaca() + "', "
                + "'" + veiculo.getCategoria() + "', "
                + "'" + veiculo.getNumero_maximo_de_passageiros() + "', "
                + "'" + veiculo.getTamanho_do_bagageiro() + "', "
                + "'" + veiculo.getTipo_de_cambio() + "', "
                + "'" + veiculo.getPossui_ar_condicionado() + "', "
                + "'" + veiculo.getMedia_de_consumo() + "', "
                + "'" + veiculo.getAcessorios() + "', "
                + "'" + veiculo.getCusto_por_dia() + "')";
        try {
            database.execSQL(sql);
            Toast.makeText(context, "Veiculo cadastrado!", Toast.LENGTH_SHORT).show();
            return true;
        }
        catch (SQLException e) {
            Toast.makeText(context, "Erro! " + e.getMessage(), Toast.LENGTH_SHORT).show();
            return false;
        }
    }
    public boolean remover(Veiculo veiculo) {
        int id = veiculo.getId();
        String sql = "DELETE FROM veiculos WHERE id = " + id;
        try {
            database.execSQL(sql);
            Toast.makeText(context, "Veículo removido!", Toast.LENGTH_SHORT).show();
            return true;
        }
        catch (SQLException e) {
            Toast.makeText(context, "Erro! " + e.getMessage(), Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    public boolean update(Veiculo veiculo) {
        String sql = "UPDATE veiculos SET "
                + "Placa='" + veiculo.getPlaca() + "', "
                + "Categoria='" + veiculo.getCategoria() + "', "
                + "Numero_maximo_de_passageiros='" + veiculo.getNumero_maximo_de_passageiros() + "', "
                + "Tamanho_do_bagageiro='" + veiculo.getTamanho_do_bagageiro() + "', "
                + "Tipo_de_cambio='" + veiculo.getTipo_de_cambio() + "', "
                + "Possui_ar_condicionado='" + veiculo.getPossui_ar_condicionado() + "', "
                + "Media_de_consumo='" + veiculo.getMedia_de_consumo() + "', "
                + "Acessorios='" + veiculo.getAcessorios() + "', "
                + "Custo_por_dia='" + veiculo.getCusto_por_dia() + "' "
                + "WHERE id=" + veiculo.getId();
        try {
            database.execSQL(sql);
            Toast.makeText(context, "Informações atualizadas!", Toast.LENGTH_SHORT).show();
            return true;
        }
        catch (SQLException e) {
            Toast.makeText(context, "Erro! " + e.getMessage(), Toast.LENGTH_SHORT).show();
            return false;
        }
    }
    public int TotalPagamento(int veiculoID,String dataRet, String dataDev, int opc){
        int total = 0;

        VeiculoDAO veiculoDAO = new VeiculoDAO(context);
        Veiculo veiculo = veiculoDAO.get(veiculoID);
        int dia = Integer.parseInt(veiculo.getCusto_por_dia());

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        Date firstDate = null;
        try {
            firstDate = sdf.parse(dataRet);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        Date secondDate = null;
        try {
            secondDate = sdf.parse(dataDev);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        long diff = secondDate.getTime() - firstDate.getTime();
        TimeUnit time = TimeUnit.DAYS;
        long diffrence = time.convert(diff, TimeUnit.MILLISECONDS);
        if(diffrence < 0){
            return -1;
        }
        ///System.out.println("The difference in days is : "+diffrence);
        total = (int) (diffrence * dia) + opc;

        return total;
    }

    public Veiculo get(int id) {
        String sql = "SELECT * FROM veiculos WHERE id=" + id;
        Cursor cursor = database.rawQuery(sql, null);

        if (cursor.moveToNext()) {
            String Placa = cursor.getString(1);
            String Categoria = cursor.getString(2);
            String Numero_maximo_de_passageiros = cursor.getString(3);
            String Tamanho_do_bagageiro = cursor.getString(4);
            String Tipo_de_cambio = cursor.getString(5);
            String Possui_ar_condicionado = cursor.getString(6);
            String Media_de_consumo = cursor.getString(7);
            String Acessorios = cursor.getString(8);
            String Custo_por_dia = cursor.getString(9);
            return new Veiculo(id, Placa, Categoria, Numero_maximo_de_passageiros,Tamanho_do_bagageiro,Tipo_de_cambio,Possui_ar_condicionado,Media_de_consumo,
                    Acessorios,Custo_por_dia);
        }
        return null;
    }
}
