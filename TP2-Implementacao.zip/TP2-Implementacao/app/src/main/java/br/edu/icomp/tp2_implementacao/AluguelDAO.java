package br.edu.icomp.tp2_implementacao;

import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Toast;

import java.util.ArrayList;

public class AluguelDAO {
    private Context context;
    private SQLiteDatabase database;

    public AluguelDAO(Context context) {
        this.context = context;
        this.database = (new Database(context)).getWritableDatabase();
    }

    public ArrayList<Aluguel> getList() {
        ArrayList<Aluguel> result = new ArrayList<Aluguel>();
        String sql = "SELECT * FROM alugados ORDER BY Placa_Carro_Alugado";
        Cursor cursor = database.rawQuery(sql, null);

        while (cursor.moveToNext()) {
            int id = cursor.getInt(0);
            String Placa_Carro_Alugado = cursor.getString(1);
            String Nome_completo = cursor.getString(2);
            String Local_de_retirada = cursor.getString(3);
            String Data_de_retirada = cursor.getString(4);
            String Local_de_devolucao = cursor.getString(5);
            String Data_de_devolucao = cursor.getString(6);
            String Opcionais = cursor.getString(7);
            String valoTotal = cursor.getString(8);
            result.add(new Aluguel(id, Placa_Carro_Alugado, Nome_completo, Local_de_retirada,Data_de_retirada,Local_de_devolucao,Data_de_devolucao,Opcionais,valoTotal));
        }
        return result;
    }

    public boolean add(Aluguel aluguel) {
        String sql = "INSERT INTO alugados VALUES (NULL, "
                + "'" + aluguel.getPlaca_Carro_Alugado() + "', "
                + "'" + aluguel.getNome_completo() + "', "
                + "'" + aluguel.getLocal_de_retirada() + "', "
                + "'" + aluguel.getData_de_retirada() + "', "
                + "'" + aluguel.getLocal_de_devolucao() + "', "
                + "'" + aluguel.getData_de_devolucao() + "', "
                + "'" + aluguel.getOpcionais() + "', "
                + "'" + aluguel.getValorTotal() + "')";
        try {
            database.execSQL(sql);
            Toast.makeText(context, "Veiculo Alugado com sucesso!!!", Toast.LENGTH_SHORT).show();
            return true;
        }
        catch (SQLException e) {
            Toast.makeText(context, "Erro! " + e.getMessage(), Toast.LENGTH_SHORT).show();
            return false;
        }
    }
    public boolean remover(Aluguel aluguel) {
        int id = aluguel.getID();
        String sql = "DELETE FROM alugados WHERE id = " + id;
        try {
            database.execSQL(sql);
            Toast.makeText(context, "Aluguel removido!", Toast.LENGTH_SHORT).show();
            return true;
        }
        catch (SQLException e) {
            Toast.makeText(context, "Erro! " + e.getMessage(), Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    public boolean update(Aluguel aluguel) {
        String sql = "UPDATE alugados SET "
                + "Placa_Carro_Alugado='" + aluguel.getPlaca_Carro_Alugado() + "', "
                + "Nome_completo='" + aluguel.getNome_completo() + "', "
                + "Local_de_retirada='" + aluguel.getLocal_de_retirada() + "', "
                + "Data_de_retirada='" + aluguel.getData_de_retirada() + "', "
                + "Local_de_devolucao='" + aluguel.getLocal_de_devolucao() + "', "
                + "Data_de_devolucao='" + aluguel.getData_de_devolucao() + "', "
                + "Opcionais='" + aluguel.getOpcionais() + "', "
                + "valorTotal='" + aluguel.getValorTotal() + "' "
                + "WHERE id=" + aluguel.getID();
        try {
            database.execSQL(sql);
            Toast.makeText(context, "Informações atualizadas!", Toast.LENGTH_SHORT).show();
            return true;
        }
        catch (SQLException e) {
            Toast.makeText(context, "Erro! " + e.getMessage(), Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    public Aluguel get(int id) {
        String sql = "SELECT * FROM alugados WHERE id=" + id;
        Cursor cursor = database.rawQuery(sql, null);

        if (cursor.moveToNext()) {
            String Placa_Carro_Alugado = cursor.getString(1);
            String Nome_completo = cursor.getString(2);
            String Local_de_retirada = cursor.getString(3);
            String Data_de_retirada = cursor.getString(4);
            String Local_de_devolucao = cursor.getString(5);
            String Data_de_devolucao = cursor.getString(6);
            String Opcionais = cursor.getString(7);
            String valoTotal = cursor.getString(8);
            return new Aluguel(id, Placa_Carro_Alugado, Nome_completo, Local_de_retirada,Data_de_retirada,Local_de_devolucao,Data_de_devolucao,Opcionais,valoTotal);
        }
        return null;
    }
    public boolean buscaPlaca(String placa) {
        String sql = "SELECT * FROM alugados";
        Cursor cursor = database.rawQuery(sql, null);

        while (cursor.moveToNext()) {
            if (cursor.getString(1).equals(placa)) {
                return true;
            }
        }
        return false;
    }
}
