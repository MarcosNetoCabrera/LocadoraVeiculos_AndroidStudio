package br.edu.icomp.tp2_implementacao;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class telaAluguel extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    private int veiculoID;
    private TextView date1,date2;
    VeiculoDAO veiculoDAO;
    ClienteDAO clienteDAO;
    AluguelDAO aluguelDAO;
    private int clienteID;
    private int valorTotal,GPS,Assento,Seguro;
    private Spinner spinnerDevolucao,spinnerRetirada;
    private RadioButton radioGPS,radioAssento,radioSeguro;
    private Button bt_confirmar;
    AlertDialog.Builder msgBox;
    private String local_retirada,local_devolucao,data_retirada,data_devolucao,opcionais;

    public void inicializa(){
        spinnerDevolucao = findViewById(R.id.spinnerDevolucao);
        spinnerRetirada = findViewById(R.id.spinnerRetirada);
        date1 = findViewById(R.id.edit_Data_de_retirada);
        date2 = findViewById(R.id.edit_Data_de_devolucao);
        radioGPS = findViewById(R.id.radioButtonGPS);
        radioAssento = findViewById(R.id.radioButtonAssento);
        radioSeguro = findViewById(R.id.radioButtonSeguro);
        bt_confirmar = findViewById(R.id.buttonConfirmarInformacoes);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_aluguel);
        getSupportActionBar().hide();
        inicializa();

        veiculoDAO = new VeiculoDAO(this);
        Intent intent = getIntent();
        veiculoID = intent.getIntExtra("veiculoID", -1);

        clienteDAO = new ClienteDAO(this);
        intent = getIntent();
        clienteID = intent.getIntExtra("clienteID", -1);

        aluguelDAO = new AluguelDAO(this);


        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,R.array.Locais1, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerRetirada.setAdapter(adapter);
        spinnerRetirada.setOnItemSelectedListener(this);


        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(this,R.array.Locais2, android.R.layout.simple_spinner_item);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerDevolucao.setAdapter(adapter2);
        spinnerDevolucao.setOnItemSelectedListener(this);

        msgBox = new AlertDialog.Builder(this);

        bt_confirmar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                data_retirada = date1.getText().toString();
                data_devolucao = date2.getText().toString();

                if(data_retirada.isEmpty() || data_devolucao.isEmpty() || local_devolucao.equals("Selecione o Local de retirada") || local_retirada.equals("Selecione o Local de  devolução")){
                    Toast.makeText(telaAluguel.this,"Preencha todos os campos", Toast.LENGTH_SHORT).show();
                }else{
                    opcionais = "";
                    if(radioGPS.isChecked()) {
                        GPS = 200;
                        opcionais += "GPS ";
                    }
                    if(radioAssento.isChecked()){
                        Assento = 700;
                        opcionais += "Assento ";
                    }
                    if(radioSeguro.isChecked()){
                        Seguro = 3000;
                        opcionais += "Seguro ";
                    }

                    valorTotal = GPS+Assento+Seguro;

                    int pagamento = veiculoDAO.TotalPagamento(veiculoID,data_retirada,data_devolucao,valorTotal);

                    if (pagamento == -1) {
                        Toast.makeText(telaAluguel.this,"A data de devolução deve ser maior que a de retirada", Toast.LENGTH_SHORT).show();
                    }else{
                    msgBox.setTitle("Confirmar Aluguel");
                    msgBox.setMessage("O valor total das diárias mais os opcionais escolhidos será de R$ "+pagamento+", você deseja confirmar o aluguel ?");
                    msgBox.setPositiveButton("Confirmar", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            String valorPagamento = Integer.toString(pagamento);
                            Aluguel aluguel = new Aluguel(-1,veiculoDAO.get(veiculoID).getPlaca(),clienteDAO.get(clienteID).getNome(),local_retirada,
                                    data_retirada,local_devolucao,data_devolucao,opcionais,valorPagamento);
                            aluguelDAO.add(aluguel);
                            Intent intent = new Intent(telaAluguel.this,telaControle.class);
                            intent.putExtra("clienteID",clienteID);
                            intent.putExtra("veiculoID", veiculoID);
                            startActivity(intent);
                        }
                    });
                    msgBox.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            finish();
                        }
                    });
                        msgBox.show();
                    }
                }
            }
        });
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int i, long l) {
        switch (parent.getId()){
            case R.id.spinnerRetirada:{
                local_devolucao = parent.getItemAtPosition(i).toString();
            }
            case R.id.spinnerDevolucao:{
                local_retirada = parent.getItemAtPosition(i).toString();
            }
        }
    }
    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}