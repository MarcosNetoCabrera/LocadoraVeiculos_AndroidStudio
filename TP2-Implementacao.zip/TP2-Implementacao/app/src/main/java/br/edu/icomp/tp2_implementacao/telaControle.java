package br.edu.icomp.tp2_implementacao;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class telaControle extends AppCompatActivity {
    private Button bt_controleClientes,bt_controleVeiculos,bt_controleAlugados;
    private int clienteID;
    ClienteDAO clienteDAO;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_controle);

        getSupportActionBar().hide();

        clienteDAO = new ClienteDAO(this);
        Intent intent = getIntent();
        clienteID = intent.getIntExtra("clienteID", -1);


        bt_controleClientes = findViewById(R.id.buttonControleClientes);
        bt_controleClientes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(telaControle.this,telaControleClientes.class);
                startActivity(intent);
            }
        });
        bt_controleVeiculos = findViewById(R.id.buttonControleVeiculos);
        bt_controleVeiculos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(telaControle.this,telaControleVeiculos.class);
                startActivity(intent);
            }
        });
        bt_controleAlugados = findViewById(R.id.buttonAlugar);
        bt_controleAlugados.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(telaControle.this,telaControleAluguel.class);
                intent.putExtra("clienteID",clienteID);
                startActivity(intent);
            }
        });
    }
}