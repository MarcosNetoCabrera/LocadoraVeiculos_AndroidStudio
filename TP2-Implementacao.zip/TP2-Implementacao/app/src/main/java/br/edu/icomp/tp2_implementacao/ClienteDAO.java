package br.edu.icomp.tp2_implementacao;

import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Toast;

import java.util.ArrayList;

public class ClienteDAO {

    private Context context;
    private SQLiteDatabase database;

    public ClienteDAO(Context context) {
        this.context = context;
        this.database = (new Database(context)).getWritableDatabase();
    }

    public ArrayList<Cliente> getList() {
        ArrayList<Cliente> result = new ArrayList<Cliente>();
        String sql = "SELECT * FROM clientes ORDER BY nome";
        Cursor cursor = database.rawQuery(sql, null);

        while (cursor.moveToNext()) {
            int id = cursor.getInt(0);
            String name = cursor.getString(1);
            String senha = cursor.getString(2);
            String idade = cursor.getString(3);
            result.add(new Cliente(id, name, senha, idade));
        }
        return result;
    }
    public boolean add(Cliente cliente) {
        String sql = "INSERT INTO clientes VALUES (NULL, "
                + "'" + cliente.getNome() + "', "
                + "'" + cliente.getSenha() + "', "
                + "'" + cliente.getIdade() + "')";
        try {
            database.execSQL(sql);
            Toast.makeText(context, "Cliente cadastrado!", Toast.LENGTH_SHORT).show();
            return true;
        }
        catch (SQLException e) {
            Toast.makeText(context, "Erro! " + e.getMessage(), Toast.LENGTH_SHORT).show();
            return false;
        }
    }
    public boolean remover(Cliente cliente) {
        int id = cliente.getId();
        String sql = "DELETE FROM clientes WHERE id = " + id;
        try {
            database.execSQL(sql);
            Toast.makeText(context, "Cliente removido!", Toast.LENGTH_SHORT).show();
            return true;
        }
        catch (SQLException e) {
            Toast.makeText(context, "Erro! " + e.getMessage(), Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    public boolean update(Cliente cliente) {
        String sql = "UPDATE clientes SET "
                + "nome='" + cliente.getNome() + "', "
                + "senha='" + cliente.getSenha() + "', "
                + "idade='" + cliente.getIdade() + "' "
                + "WHERE id=" + cliente.getId();
        try {
            database.execSQL(sql);
            Toast.makeText(context, "Informações atualizadas!", Toast.LENGTH_SHORT).show();
            return true;
        }
        catch (SQLException e) {
            Toast.makeText(context, "Erro! " + e.getMessage(), Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    public Cliente get(int id) {
        String sql = "SELECT * FROM clientes WHERE id=" + id;
        Cursor cursor = database.rawQuery(sql, null);

        if (cursor.moveToNext()) {
            String nome = cursor.getString(1);
            String senha = cursor.getString(2);
            String idade = cursor.getString(3);
            return new Cliente(id, nome, senha, idade);
        }

        return null;
    }

    public Cliente BuscarSenha(String senha) {
        String sql = "SELECT * FROM clientes WHERE senha=" + senha;
        Cursor cursor = database.rawQuery(sql, null);

        if (cursor.moveToNext()) {
            int id = cursor.getInt(0);
            String nome = cursor.getString(1);
            String idade = cursor.getString(3);
            return new Cliente(id, nome, senha, idade);
        }

        return null;
    }

}
